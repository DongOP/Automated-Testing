This package shows how to use an extension of Page Obgect design pattern. These features were designed to simplify
the modeling of interaction with a target app and to be reused in desktop/mobile browser testing/testing of mobile apps.

Details please read here: [#267](https://github.com/appium/java-client/pull/267)