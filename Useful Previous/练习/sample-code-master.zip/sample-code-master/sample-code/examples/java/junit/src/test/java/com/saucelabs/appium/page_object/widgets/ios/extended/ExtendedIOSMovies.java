package com.saucelabs.appium.page_object.widgets.ios.extended;

import com.saucelabs.appium.page_object.widgets.ios.annotated.AnnotatedIOSMovies;
import org.openqa.selenium.WebElement;

public class ExtendedIOSMovies extends AnnotatedIOSMovies {
    protected ExtendedIOSMovies(WebElement element) {
        super(element);
    }
}
